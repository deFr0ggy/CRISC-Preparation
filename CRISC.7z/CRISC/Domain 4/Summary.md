# Summary

	- Risk is identified and assessed. 
	- It is the responsibility of the risk ownsers to select the appropriate resposne to the risk and create risk action plans to implement or modify controls selected to mitigate risk.
	- As controls to mitigate the risk are designed and developed, the risk ownser also mandates the development of the ability to monitor and report on the effectiveness of the controls.
	- regular monitoring and rpeorting on the risk is essential to the management and the use of KPIs and KRIs assists management in the monitoring of trends, complianc and issues related to risk.
	- Risk management is a never ending process
	- IT risks and controls should be continuoudly monitored and reported on to ensure continued effeciency and effectiveness.
	
