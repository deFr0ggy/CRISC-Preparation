# Domain 2.6 - Risk Management For IT Projects

It is to remember that a project is always finite and produces a unique product, service or result. 

PMI Framework (Project Management Institute Framework) also includes the Risk Management for the project. 

`
The best time to address the risks is before they happen! 
`

PMI ITTOs are provided as below. 
- Input 
- Tools/Techniques
- Outputs

## Managing Risks In Projects
1. Identify Risks
2. Perform Quantative Analysis
3. Plan Risk Responses 
4. Control Risks

