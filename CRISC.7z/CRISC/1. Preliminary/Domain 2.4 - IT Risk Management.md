# Domain 2.4 - IT Risk Management

## 1. Business Risk vs IT Risk
- IT risk is a subset of business risk. 
- IT risk is a business risk.
- Risk Practioner Must
	- Understand the organizational culture
	- Cot calculate risk solely from an IT perspective
	- Support the business
	- Examine areas such as Business Continuity, IS Audit, Information Systems, IS Controls, Projects and Changes.

## IT Risks and Information Security 
- ** Control Risk **
	- Control Chosen to mitigate the risk
	- Improperly working
	- Wrong control, incorrect configuration etc. 
- **Project Risk**
	- Many projects fails
	- Over budget, over time, failure to meet expectations. 
- **Change Risk**
	- Associated with new system and processes.

## Business Continuity & Risk Management
- Risk assessment precursor to BIA (Business Impact Analysis).
- Attempts to reduce IT Risks to acceptable level
- Often risk management is focused on "known unknown", "if then"
- BCP ius focused on "unknown unknowns"

## Contect of IT Risk Management 
- Risk Management - Coordinated activites to direct and control and enterprise with regard to risk
- Understanding of the organization and its context, or environement. 
- Assess the context includes
	- Intent and capabiluty of threats
	- Assets
	- Relationship of vulnerabilities
	- Vulnerability to changes in economic or political conditions.
	- Changes to market trends and patterns.
	- Emergence of new competition
	- Impact of new legislation
	- Existence of potential natural disaster
	- Constraints caused by legacy systems and antiquated technology
	- Strained labor relations and inflexible management. 
	
	
