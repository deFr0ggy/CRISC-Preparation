# Domain 2.2 - Risk Governance VS Risk Management

## Risk Governance
We need to look at the top of the organization where we have Board of Directors, Senior Management, ITSCs. They are responsible for Risk Governance. They are also responsible for defining the business goals, company vision, culture, risk apetite etc. 

There are generally 4 main components
1. Establish and maintain a common risk view. 
	1. Within the organzation we have the risk structure, risk context and risk apetite is defined. 
	2. It is upto senior management that RISK is standardized in the organization. 
2. Selection of RMF and implementing into everything. 
	1. Risk Management = Security Management = Information Security
3. Make risk-aware business decisions
4. Ensure that the risk management controls are implement and are operating correctly. 

## Questions for Governance
1. Are we doing the right things?
2. Are we doing them the right way?
3. Are we getting them done well?
4. Are we getting the benefits?

`
Governance is all about delivering value to the organization.
`

## Risk Management 
Management is conducted by funcational leaders like department heads etc. Management has to figure out how to perform Risk Management. Risk Management focuses on planning, building, running and monitoring to create value by achieving objectives set by the governance system. 
Risk Management forsees challenges to achieving objectives and attempts to lower probability and impact of those challenges to a degree that's acceptable by senior mangement. 

`
Governance is WHAT and Management is HOW
`




