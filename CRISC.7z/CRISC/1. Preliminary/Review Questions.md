# Review Questions

1. Risk Should be reduced until 
A) Eliminated
*B) Accepted*
C) Transferred
D) Avoided

2. What are the phases of ISACA Risk Management Lifecycle. 
*At first we Identify the risk, then assess the risk, we then mitigate the risk, apply controls and finally keep monitoring.*

There are total of 5 Phases in RISK MANAGEMENT.

1 Identify The Risks
2 Analyse/Assess The Risks
3 Mitigate The Risk
4 Control The Risk
5 Monitoring

3. Which of the following is not an element of the Security Triad?
*A) Authenticity*
B) Confidentiality
C) Integrity
D) Availability

4. Which term is best described as "The acceptable level of variation that management is willing to allow for any particular risk"
A) Risk Appretite
B) Risk Threshold
*C) Risk Tolerance *
D) Risk Capacity


